import { GoogleGenAI, GenerateContentResponse, Modality, Type } from '@google/genai';
import { VIEW_ANGLES } from '../constants';
import { OutfitCategory, AvaTone } from '../types';
import { fileToBase64 } from '../utils';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

// New constants for poses based on user-provided images
const MALE_POSE_DESCRIPTION = "standing facing directly forward, with arms crossed confidently over their chest";
const FEMALE_POSE_DESCRIPTION = "standing facing directly forward, with hands gently clasped together in front of them";

const base64ToGenerativePart = (base64: string, mimeType: string = 'image/jpeg') => {
    return {
        inlineData: { data: base64, mimeType }
    };
};

// New function to detect gender from an image
export const detectGender = async (base64Image: string): Promise<'Male' | 'Female' | 'Unknown'> => {
    if (!ai) throw new Error("API key not configured.");
    try {
        const imagePart = base64ToGenerativePart(base64Image);
        const result: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    imagePart,
                    { text: "Analyze the person in the image. Is the person male or female? Respond with only the word 'Male' or 'Female'." }
                ]
            }
        });
        const genderText = result.text.trim().toLowerCase();
        if (genderText === 'male') return 'Male';
        if (genderText === 'female') return 'Female';
        return 'Unknown';
    } catch (error) {
        console.error("Gender detection failed:", error);
        return 'Unknown'; // Fallback
    }
};

export const generateCleanFrontView = async (file: File): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");

    const base64Image = await fileToBase64(file);
    const gender = await detectGender(base64Image);
    const pose = gender === 'Male' ? MALE_POSE_DESCRIPTION : FEMALE_POSE_DESCRIPTION;

    const imagePart = {
      inlineData: { data: base64Image, mimeType: file.type },
    };

    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                imagePart,
                { text: `Create a photorealistic, clean, full-body studio photograph of the person in this image. The background should be a solid light gray (#E8E8E8) with a subtle film grain texture, similar to a professional studio photoshoot. The person must be in the following pose: ${pose}. Keep the original outfit and person's appearance. If the person is not wearing shoes, add footwear that is appropriate and stylish for the outfit. The output image must have a 3:4 portrait aspect ratio to show the full body without cropping.` }
            ]
        },
        config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
        }
    });
    
    const image = result.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;
    if (!image) throw new Error("AI failed to generate front view image.");
    return image;
};

export const generate360Views = async (frontViewImage: string): Promise<string[]> => {
    if (!ai) throw new Error("API key not configured.");

    const gender = await detectGender(frontViewImage);
    const pose = gender === 'Male' ? MALE_POSE_DESCRIPTION : FEMALE_POSE_DESCRIPTION;

    const referenceImagePart = base64ToGenerativePart(frontViewImage);
    const generatedImages: string[] = [frontViewImage];

    for (const angle of VIEW_ANGLES.slice(1)) { // Skip 'Front'
        const result: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    referenceImagePart,
                    { text: `Using the provided image as a reference for the person and their outfit, generate a photorealistic, full-body studio photograph of them from the ${angle} view. The person should be in a pose consistent with this description: ${pose}. The background must be identical to the background in the reference image. The output image must have a 3:4 portrait aspect ratio.` }
                ]
            },
            config: {
              responseModalities: [Modality.IMAGE, Modality.TEXT],
            }
        });
        const image = result.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;
        if (image) {
            generatedImages.push(image);
        } else {
            console.warn(`Failed to generate view for angle: ${angle}`);
            generatedImages.push(frontViewImage); // Use front view as fallback
        }
    }
    return generatedImages;
};

export const categorizeOutfit = async (frontViewImage: string): Promise<OutfitCategory> => {
    if (!ai) throw new Error("API key not configured.");
    const imagePart = base64ToGenerativePart(frontViewImage);
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                imagePart,
                { text: "Analyze the outfit in the image. Categorize it into one of the following categories: Party, Casual, Date, Office. Respond with only the category name." }
            ]
        }
    });
    const categoryText = result.text.trim().toUpperCase();
    
    // Ensure the AI's response is a valid and acceptable category.
    // Explicitly prevent "FAVORITES" or "ALL" from being assigned by the AI.
    if (
        Object.values(OutfitCategory).includes(categoryText as OutfitCategory) &&
        categoryText !== OutfitCategory.FAVORITES &&
        categoryText !== OutfitCategory.ALL
    ) {
        return categoryText as OutfitCategory;
    }
    
    return OutfitCategory.UNKNOWN;
};

export const generateOutfitDescription = async (frontViewImage: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");
    const imagePart = base64ToGenerativePart(frontViewImage);
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                imagePart,
                { text: "Provide a short, chic, and descriptive summary of the outfit in the image, suitable for a fashion app. Focus on the style, key pieces, and potential occasions. Keep it under 50 words." }
            ]
        }
    });
    return result.text;
};

export const generateStylingTips = async (frontViewImage: string, outfitCategory: string, userStyleProfile: string, userName: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");
    const imagePart = base64ToGenerativePart(frontViewImage);
    
    const prompt = `You are AVA, a friendly and sharp AI stylist. The user, ${userName}, has a style profile described as: "${userStyleProfile}".
They are looking at their '${outfitCategory}' outfit.
Based on the image and their profile, provide some practical styling tips. Suggest specific accessories, footwear, or occasions this outfit would be perfect for. Make it sound personal and encouraging. Keep the advice concise and under 70 words.`;
    
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                imagePart,
                { text: prompt }
            ]
        }
    });
    return result.text;
};

export const generateOutfitCompliment = async (frontViewImage: string, userName: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");
    const imagePart = base64ToGenerativePart(frontViewImage);
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                imagePart,
                { text: `Analyze the outfit in the image. Write an engaging and complimentary description directly to the user, whose name is ${userName}. Compliment their style, mention the key pieces, and suggest where they might wear it. Keep the tone friendly, positive, and chic. Aim for 50-70 words.` }
            ]
        }
    });
    return result.text;
};

export const createAvatar = async (faceReferenceImage: string, outfitReferenceImage: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");
    
    // Gender and pose are determined by the full-body outfit image
    const gender = await detectGender(outfitReferenceImage);
    const pose = gender === 'Male' ? MALE_POSE_DESCRIPTION : FEMALE_POSE_DESCRIPTION;
    const clothingDescription = gender === 'Male'
        ? "a muscle-fitted, plain, clear white t-shirt and muscle-fitted, plain, clear white shorts"
        : "a muscle-fitted, plain, clear white top and muscle-fitted, plain, clear white shorts";

    const facePart = base64ToGenerativePart(faceReferenceImage);
    const outfitPart = base64ToGenerativePart(outfitReferenceImage);
    const promptText = `Using the first image as a reference for the person's face and head, and the second image as a reference for their body shape and pose, create a new photorealistic, full-body studio photograph. The new image must meet these criteria: 1. The person's face and head must be an exact, photorealistic match to the first image. 2. The person's body and pose must match the second image. 3. Change their clothing to ${clothingDescription}. 4. The background must be a solid light gray (#E8E8E8) with a subtle film grain texture, similar to a professional studio photoshoot. 5. The output image must have a 3:4 portrait ratio.`;
    
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                facePart,
                outfitPart,
                { text: promptText }
            ]
        },
        config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
        }
    });

    // --- Enhanced Response Parsing & Error Handling ---
    if (!result.candidates || result.candidates.length === 0) {
        console.error("Avatar generation failed. API response:", JSON.stringify(result, null, 2));
        const blockReason = result.promptFeedback?.blockReason;
        if (blockReason) {
            throw new Error(`Avatar generation was blocked: ${blockReason}. Please try a different image.`);
        }
        throw new Error("AI service returned an empty response, possibly due to safety filters.");
    }

    const imagePartFound = result.candidates[0].content?.parts?.find(p => p.inlineData);
    if (!imagePartFound) {
        console.error("AI failed to return an image. API response:", JSON.stringify(result, null, 2));
        const textResponse = result.candidates[0].content?.parts?.find(p => p.text)?.text;
        if (textResponse) {
            throw new Error(`AI returned text instead of an image: "${textResponse}"`);
        }
        throw new Error("AI failed to generate avatar image.");
    }
    
    return imagePartFound.inlineData.data;
};

export const generateAvatarVideo = async (avatarImage: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");

    const imagePart = {
        imageBytes: avatarImage,
        mimeType: 'image/png',
    };

    let operation = await ai.models.generateVideos({
        model: 'veo-2.0-generate-001',
        prompt: 'A short, subtle animation of the person in the image. They should be standing still but breathing gently, with slight, natural movements like blinking or a small shift in weight. The background should remain static. This should be a seamless, 2-second loop.',
        image: imagePart,
        config: {
            numberOfVideos: 1,
        }
    });
    
    // Polling loop
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds between checks
        operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        console.error("Video generation failed. Operation response:", JSON.stringify(operation, null, 2));
        throw new Error("AI failed to generate avatar video.");
    }
    
    return `${downloadLink}&key=${API_KEY}`;
};

export const dressAvatar = async (avatarImage: string, outfitImage: string): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");

    const gender = await detectGender(avatarImage);
    const pose = gender === 'Male' ? MALE_POSE_DESCRIPTION : FEMALE_POSE_DESCRIPTION;

    const avatarPart = base64ToGenerativePart(avatarImage);
    const outfitPart = base64ToGenerativePart(outfitImage);
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                avatarPart,
                outfitPart,
                { text: `Given the first image of a person (the avatar) and the second image of an outfit on a person, create a new image where the avatar is wearing the outfit from the second image. It is crucial that you maintain the avatar's original physical appearance, facial expression, and the light gray studio background exactly as it is in the first image. The person must be in the following pose: ${pose}. Only change the clothing. The output image must have a 3:4 portrait aspect ratio.` }
            ]
        },
        config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
        }
    });
    const image = result.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;
    if (!image) throw new Error("AI failed to dress the avatar.");
    return image;
};

export const getStylingAdvice = async (chatHistory: { role: string, parts: { text: string }[] }[], savedOutfitsSummary: string, userName: string | null): Promise<string> => {
    if (!ai) throw new Error("API key not configured.");
    
    const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: chatHistory,
        config: {
            systemInstruction: `You are AVA, a friendly and sharp AI stylist. Your personality is futuristic, chic, and encouraging. Your goal is to provide personalized styling advice to ${userName || 'the user'} based on their saved outfits. Keep your responses concise and helpful. Here is a summary of the user's closet: ${savedOutfitsSummary}.`
        }
    });
    
    return result.text;
};

export interface AvaAdvice {
    advice: string;
    outfitIds: string[];
}

const getSystemInstruction = (tone: AvaTone, userName: string, savedOutfitsSummary: string): string => {
    const closetInfo = `You have access to a summary of their digital closet to make your recommendations relevant. Here is a summary of ${userName}'s closet: ${savedOutfitsSummary}.`;
    const jsonInstruction = "When you suggest an outfit from their closet, you must return its ID in the 'outfitIds' field of the JSON response, but DO NOT mention the ID in your conversational 'advice' text.";

    switch (tone) {
        case AvaTone.PROFESSIONAL:
            return `You are AVA, a highly professional AI fashion consultant. Your goal is to provide expert styling advice to a user named ${userName}. Your responses should be clear, concise, and informative. Maintain a formal and respectful tone. ${closetInfo} ${jsonInstruction}`;
        case AvaTone.GENZ:
            return `You are AVA, a stylist who's also ${userName}'s homie. Your goal is to give them legit style advice. Talk like a Gen Z fashion expert. Use modern slang like 'vibe', 'slay', 'fire', 'bet', 'no cap', 'drip'. Keep it chill and low-key. ${closetInfo} ${jsonInstruction}`;
        case AvaTone.BESTIE:
            return `You are AVA, ${userName}'s best friend and ride-or-die stylist. Your goal is to be their biggest hype person. Your tone is super enthusiastic, supportive, and familiar, like you're getting ready for a night out together. Use 'we' and 'us' a lot. ${closetInfo} ${jsonInstruction}`;
        case AvaTone.FRIENDLY:
        default:
            return `You are AVA, a friendly, futuristic, chic, and encouraging AI stylist. Your goal is to provide personalized styling advice to a user named ${userName}. Be conversational and helpful. ${closetInfo} ${jsonInstruction}`;
    }
}

export const getAvaStyleAdvice = async (chatHistory: { role: string, parts: { text: string }[] }[], savedOutfitsSummary: string, userName: string, tone: AvaTone): Promise<AvaAdvice> => {
    if (!ai) throw new Error("API key not configured.");
    
    const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: chatHistory,
        config: {
            systemInstruction: getSystemInstruction(tone, userName, savedOutfitsSummary),
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    advice: {
                        type: Type.STRING,
                        description: "Your friendly, conversational styling advice for the user. Do not mention outfit IDs in this text."
                    },
                    outfitIds: {
                        type: Type.ARRAY,
                        description: "A list of outfit IDs from the user's closet that are relevant to your advice. Only include IDs provided in the closet summary.",
                        items: {
                            type: Type.STRING,
                        }
                    }
                },
                required: ["advice", "outfitIds"]
            },
        }
    });
    
    const jsonStr = result.text.trim();
    try {
        const parsed = JSON.parse(jsonStr);
        if (!parsed.outfitIds) {
            parsed.outfitIds = [];
        }
        return parsed as AvaAdvice;
    } catch (e) {
        console.error("Failed to parse AVA's JSON response:", e, "Raw response:", jsonStr);
        // Fallback for non-JSON responses
        return {
            advice: jsonStr,
            outfitIds: []
        };
    }
};

export const isApiKeySet = (): boolean => !!API_KEY;