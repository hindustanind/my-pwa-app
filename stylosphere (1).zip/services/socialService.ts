// This file has been populated with stub functions as part of a feature removal.
// This prevents legacy imports from crashing the application.
export const getFeed = async () => { 
    console.warn("socialService.getFeed is a stub and will not return real data.");
    return { posts: [] }; 
};
export const getUserPosts = async (userId: string) => { 
    console.warn("socialService.getUserPosts is a stub and will not return real data.");
    return []; 
};
export const createPost = async (outfitId: string, caption: string) => { 
    console.warn("socialService.createPost is a stub and will not create a post.");
    return { id: 'new-post' }; 
};
export const deletePost = async (postId: string) => { 
    console.warn("socialService.deletePost is a stub.");
};
export const followUser = async (userId: string) => { 
    console.warn("socialService.followUser is a stub.");
};
export const unfollowUser = async (userId: string) => { 
    console.warn("socialService.unfollowUser is a stub.");
};

// Add a default export just in case it's needed by legacy code.
export default {
    getFeed,
    getUserPosts,
    createPost,
    deletePost,
    followUser,
    unfollowUser,
};
