import React from 'react';
import { Outfit, User } from '../../types';
import Modal from '../shared/Modal';
import OutfitDetailView from './OutfitDetailView';

interface OutfitDetailModalProps {
  outfit: Outfit;
  onClose: () => void;
  isDevMode: boolean;
  currentUser: User;
}

const OutfitDetailModal: React.FC<OutfitDetailModalProps> = ({ outfit, onClose, isDevMode, currentUser }) => {
  return (
    <Modal isOpen={true} onClose={onClose} title="Outfit Details">
      <OutfitDetailView outfit={outfit} isDevMode={isDevMode} currentUser={currentUser} />
    </Modal>
  );
};

export default OutfitDetailModal;