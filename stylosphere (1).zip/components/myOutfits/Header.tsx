
import React from 'react';
import { useAuth } from '../../contexts/AuthContext';

type Page = 'home' | 'generator' | 'closet' | 'ava' | 'profile';

interface HeaderProps {
    currentPage: Page;
    setCurrentPage: (page: Page, userId?: string | null) => void;
    isDevMode: boolean;
    setIsDevMode: (isDevMode: boolean) => void;
    onRestartTutorial: () => void;
    isInstallable: boolean;
    onInstallClick: () => void;
}

const DevModeToggle: React.FC<{ isDevMode: boolean, setIsDevMode: (isDevMode: boolean) => void, onRestartTutorial: () => void }> = ({ isDevMode, setIsDevMode, onRestartTutorial }) => (
    <div className="flex items-center space-x-4">
        <button onClick={onRestartTutorial} className="text-sm font-medium text-gray-400 hover:text-[#00f2ff] transition-colors">Restart Tour</button>
        <div className="w-px h-6 bg-white/20"></div>
        <div className="flex items-center space-x-2">
            <span className={`text-sm font-medium ${isDevMode ? 'text-[#00f2ff]' : 'text-gray-400'}`}>Dev Mode</span>
            <label htmlFor="dev-mode-toggle" className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="dev-mode-toggle" className="sr-only peer" checked={isDevMode} onChange={(e) => setIsDevMode(e.target.checked)} />
                <div className="w-11 h-6 bg-gray-600 rounded-full peer peer-focus:ring-2 peer-focus:ring-[#00f2ff] peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all duration-300 peer-checked:bg-gradient-to-r from-[#f400f4] to-[#00f2ff]"></div>
            </label>
        </div>
    </div>
);

interface NavLinkProps {
    id: Page;
    label: string;
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
}

const NavLink: React.FC<NavLinkProps> = ({ id, label, currentPage, setCurrentPage }) => {
    const isActive = currentPage === id;
    return (
        <button 
            onClick={() => setCurrentPage(id)} 
            className="relative text-lg font-medium text-gray-300 hover:text-white transition-all duration-500 transform hover:-translate-y-1"
        >
            {label}
            {isActive && (
                <span className="absolute left-0 -bottom-1 w-full h-0.5 bg-gradient-to-r from-[#f400f4] to-[#00f2ff]"></span>
            )}
        </button>
    );
};


const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage, isDevMode, setIsDevMode, onRestartTutorial, isInstallable, onInstallClick }) => {
    const { currentUser, logout } = useAuth();

    const navItems = [
        { id: 'home', label: 'Home' },
        { id: 'generator', label: 'Outfit Generator' },
        { id: 'closet', label: 'My Outfits' },
        { id: 'ava', label: 'AVA Stylist' },
    ];

    return (
        <header className="fixed top-0 left-0 right-0 z-40 bg-black/20 backdrop-blur-lg border-b border-white/10">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    <div className="text-3xl font-bold tracking-tighter cursor-pointer" onClick={() => setCurrentPage('home')}>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
                            StyloSphere
                        </span>
                    </div>
                    <div className="flex items-center space-x-8">
                        <nav className="hidden md:flex items-center space-x-8">
                            {navItems.map(item => <NavLink key={item.id} id={item.id as Page} label={item.label} currentPage={currentPage} setCurrentPage={(page) => setCurrentPage(page)} />)}
                        </nav>
                        <div className="flex items-center gap-4">
                             {isInstallable && (
                                <button
                                    onClick={onInstallClick}
                                    title="Install StyloSphere App"
                                    className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-[#00f2ff] backdrop-blur-sm hover:scale-105 hover:shadow-[0_0_15px_#00f2ff] hover:bg-white/20 text-sm font-semibold transition-all"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                    Install App
                                </button>
                            )}
                             <DevModeToggle isDevMode={isDevMode} setIsDevMode={setIsDevMode} onRestartTutorial={onRestartTutorial} />
                            <button 
                                onClick={() => setCurrentPage('profile', null)}
                                title="My Profile"
                                data-tutorial-id="tutorial-profile-page"
                                className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center border-2 border-transparent hover:border-[#00f2ff] transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/20 focus:ring-[#00f2ff]"
                            >
                                {currentUser?.profilePicture ? (
                                    <img src={`data:image/jpeg;base64,${currentUser.profilePicture}`} alt="Profile" className="w-full h-full object-cover rounded-full" />
                                ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-300" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                                    </svg>
                                )}
                            </button>
                            <button onClick={logout} title="Reset App" className="text-gray-400 hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h5M4 9a9 9 0 0114.65-4.65M20 20v-5h-5m0 5a9 9 0 01-14.65-4.65" /></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;