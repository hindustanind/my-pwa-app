import React, { useState, useEffect } from 'react';
import { Outfit, User } from '../../types';
import OutfitViewer from '../outfitGenerator/OutfitViewer';
import Button from '../shared/Button';
import Spinner from '../shared/Spinner';
import * as geminiService from '../../services/geminiService';

interface OutfitDetailViewProps {
  outfit: Outfit;
  isDevMode: boolean;
  currentUser: User;
}

const OutfitDetailView: React.FC<OutfitDetailViewProps> = ({ outfit, isDevMode, currentUser }) => {
  const [description, setDescription] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [isShareSupported, setIsShareSupported] = useState(false);

  useEffect(() => {
    if (navigator.share) {
      setIsShareSupported(true);
    }
  }, []);

  useEffect(() => {
    const fetchDescription = async () => {
      setIsLoading(true);
      if (outfit.isMock) {
        // Dev Mode: Use a mock description
        setDescription(`This is a mock description for a stylish ${outfit.category} outfit, generated in Developer Mode. Based on your style profile ("${currentUser.styleSignature}"), I'd suggest pairing this with some minimalist jewelry to really let the main pieces shine. Perfect for a chic city adventure!`);
        setIsLoading(false);
      } else {
        // Standard Mode: Fetch from API
        try {
          const desc = await geminiService.generateStylingTips(
              outfit.images[0],
              outfit.category,
              currentUser.styleSignature,
              currentUser.username
          );
          setDescription(desc);
        } catch (error) {
          console.error("Failed to fetch outfit description:", error);
          setDescription("Could not load styling tips.");
        } finally {
          setIsLoading(false);
        }
      }
    };
    fetchDescription();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [outfit, isDevMode, currentUser]);

  const handleDownloadImage = (imageUrl: string, angle: string) => {
    const link = document.createElement('a');
    link.href = `data:image/png;base64,${imageUrl}`;
    link.download = `StyloSphere-Outfit-${angle.replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleShare = async () => {
    if (!navigator.share) {
        alert("Web Share API is not supported in your browser.");
        return;
    }

    const dataUrl = `data:image/png;base64,${outfit.images[0]}`;
    try {
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'stylosphere-outfit.png', { type: 'image/png' });

        const shareData = {
            title: 'My StyloSphere Outfit',
            text: 'Check out my new look!',
            files: [file],
        };

        if (navigator.canShare && navigator.canShare(shareData)) {
            await navigator.share(shareData);
        } else {
            alert("Your browser doesn't support sharing files.");
        }
    } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') {
          console.log('Share was cancelled by the user.');
        } else {
          console.error('Sharing failed:', error);
          alert('An error occurred while trying to share.');
        }
    }
  };


  return (
    <div className="grid md:grid-cols-2 gap-8">
      <OutfitViewer 
        images={outfit.images} 
        showDownloadButton={true}
        onDownload={handleDownloadImage}
      />
      <div className="flex flex-col justify-center">
        <h3 className="text-3xl font-bold mb-2">
          {outfit.category}
        </h3>
        <div className="min-h-[100px] bg-white/5 p-4 rounded-md">
            {isLoading ? <Spinner /> : <p className="text-gray-300">{description}</p>}
        </div>
        <div className="mt-6 flex flex-col sm:flex-row gap-4">
            {isShareSupported ? (
                <>
                    <Button onClick={handleShare} variant="secondary" className="w-full sm:w-auto flex items-center justify-center gap-2">
                        {/* Instagram SVG Icon */}
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.85-.07-3.252-.149-4.771-1.664-4.919-4.919-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.148-3.252 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163zm0 1.442c-3.142 0-3.498.012-4.71.068-2.753.126-3.901 1.27-4.022 4.022-.056 1.212-.068 1.568-.068 4.71s.012 3.498.068 4.71c.122 2.753 1.27 3.901 4.022 4.022 1.212.056 1.568.068 4.71.068s3.498-.012 4.71-.068c2.753-.122 3.901-1.27 4.022-4.022.056-1.212.068-1.568-.068-4.71s-.012-3.498-.068-4.71c-.122-2.753-1.27-3.901-4.022-4.022-1.212-.056-1.568-.068-4.71-.068z" fill="white"></path><path d="M12 6.837c-2.84 0-5.163 2.323-5.163 5.163s2.323 5.163 5.163 5.163 5.163-2.323 5.163-5.163-2.323-5.163-5.163-5.163zm0 8.882c-2.054 0-3.719-1.665-3.719-3.719s1.665-3.719 3.719-3.719 3.719 1.665 3.719 3.719-1.665 3.719-3.719 3.719z" fill="white"></path><path d="M16.949 6.837c-.779 0-1.41.631-1.41 1.41s.631 1.41 1.41 1.41 1.41-.631 1.41-1.41-.631-1.41-1.41-1.41z" fill="white"></path></svg>
                        Share to Instagram
                    </Button>
                    <Button onClick={handleShare} variant="secondary" className="w-full sm:w-auto flex items-center justify-center gap-2">
                        {/* WhatsApp SVG Icon */}
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.38 1.25 4.82l-1.34 4.92 5.04-1.32c1.39.71 2.97 1.14 4.63 1.14h.01c5.46 0 9.91-4.45 9.91-9.91s-4.45-9.91-9.92-9.91zm0 18.23h-.01c-1.42 0-2.82-.36-4.06-1.03l-.29-.17-3.02.79.8-2.95-.19-.31c-.74-1.25-1.19-2.69-1.19-4.21 0-4.6 3.74-8.34 8.34-8.34 2.22 0 4.25.86 5.79 2.41 1.54 1.54 2.41 3.57 2.41 5.79-.01 4.6-3.75 8.34-8.35 8.34zm4.49-6.55c-.25-.12-1.47-.72-1.7-.8-.23-.08-.39-.12-.56.12-.17.25-.64.8-.79.96-.15.17-.3.19-.56.06-.26-.12-1.09-.4-2.07-1.28-.76-.69-1.28-1.55-1.43-1.8s-.02-.28.11-.39c.11-.1.25-.26.37-.39.13-.12.17-.21.25-.33.08-.12.04-.25-.02-.37-.06-.12-.56-1.34-.76-1.84s-.4-.42-.56-.42h-.5c-.17 0-.44.06-.67.31-.23.25-.87.85-.87 2.07s.9 2.4.99 2.56.09.17 1.75 2.69c1.65 2.51 2.21 2.82 2.89 3.12.91.4 1.4.33 1.8.29.48-.04 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.07-.1-.23-.16-.48-.28z" fill="white"></path></svg>
                        Share to WhatsApp
                    </Button>
                </>
            ) : (
                <p className="text-sm text-gray-500">Sharing is only available on compatible devices (like mobile).</p>
            )}
        </div>
      </div>
    </div>
  );
};

export default OutfitDetailView;