// FIX: Import useState, useEffect, useMemo, useCallback, and useRef from React.
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Outfit, Avatar, OutfitCategory } from '../../types';
import CategoryFilter from './CategoryFilter';
import OutfitCard from './OutfitCard';
import * as geminiService from '../../services/geminiService';
import Spinner from '../shared/Spinner';
import OutfitViewer from '../outfitGenerator/OutfitViewer';
import Button from '../shared/Button';
import GenerationLoader from '../outfitGenerator/GenerationLoader';
import HeadshotUploader from './HeadshotUploader';
import OutfitDeck from './OutfitDeck';
import AvatarVideoPlayer from './AvatarVideoPlayer';
import { fileToBase64 } from '../../utils';
import PoseDeck from './PoseDeck';
import { PRESET_POSES } from '../../presetPoses';

// --- INLINED COMPONENTS ---

// Dressing Room Loader
const DressingRoomLoader: React.FC = () => (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-250px)] page-transition-enter">
        <div className="animate-swing-hanger" style={{filter: 'drop-shadow(0 0 10px #00f2ff)'}}>
            <svg width="100" height="100" viewBox="0 0 24 24" fill="#00f2ff">
                <path d="M20.38 3.46 16 2a4 4 0 0 0-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"></path>
            </svg>
        </div>
        <p className="mt-8 text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
            Preparing dressing room...
        </p>
    </div>
);

const ComingSoonPlaceholder: React.FC = () => (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-350px)] text-center text-gray-400 page-transition-enter">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 mb-4 text-[#00f2ff]/50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
        </svg>
        <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff] opacity-70">
            Coming Soon!
        </h2>
        <p className="mt-2 text-lg">The Dressing Room is getting ready for its grand debut.</p>
    </div>
);


// --- MAIN COMPONENT ---

interface MyOutfitsPageProps {
    outfits: Outfit[];
    setOutfits: React.Dispatch<React.SetStateAction<Outfit[]>>;
    avatar: Avatar | null;
    setAvatar: (avatar: Avatar | null) => void;
    isDevMode: boolean;
    setSelectedOutfit: (outfit: Outfit | null) => void;
}

const MyOutfitsPage: React.FC<MyOutfitsPageProps> = ({ outfits, setOutfits, avatar, setAvatar, isDevMode, setSelectedOutfit }) => {
    const [activeCategory, setActiveCategory] = useState<OutfitCategory>(OutfitCategory.ALL);
    const [view, setView] = useState<'closet' | 'dressingRoom'>('closet');
    const [displayedView, setDisplayedView] = useState(view);
    const [animationClass, setAnimationClass] = useState('page-transition-enter');

    const [error, setError] = useState<string | null>(null);
    const [dressingRoomImages, setDressingRoomImages] = useState<string[] | null>(null);
    const [wornOutfitId, setWornOutfitId] = useState<string | null>(null);
    const [isDressing, setIsDressing] = useState(false);
    const [isProcessingAvatar, setIsProcessingAvatar] = useState(false);
    const [avatarProgress, setAvatarProgress] = useState(0);
    const [avatarStatusText, setAvatarStatusText] = useState('');
    const [isGenerating360, setIsGenerating360] = useState(false);
    const [faceImage, setFaceImage] = useState<string | null>(null);
    const [isPreparingDressingRoom, setIsPreparingDressingRoom] = useState(false);

    // Avatar creation state
    const [poseSource, setPoseSource] = useState<'my-outfits' | 'presets'>('my-outfits');
    const [selectedBodyOutfitId, setSelectedBodyOutfitId] = useState<string | null>(null);
    const [selectedPresetPoseId, setSelectedPresetPoseId] = useState<string | null>(null);

    const outfitGridRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (view !== displayedView) {
            setAnimationClass('page-transition-exit');
            const timer = setTimeout(() => {
                setDisplayedView(view);
                setAnimationClass('page-transition-enter');
            }, 300);
            return () => clearTimeout(timer);
        }
    }, [view, displayedView]);

    const filteredOutfits = useMemo(() => {
        const sorted = [...outfits].sort((a, b) => b.createdAt - a.createdAt);
        if (activeCategory === OutfitCategory.FAVORITES) {
            return sorted.filter(o => o.isFavorite);
        }
        if (activeCategory === OutfitCategory.ALL) return sorted;
        return sorted.filter(o => o.category === activeCategory);
    }, [outfits, activeCategory]);
    
    const handleSwitchToDressingRoom = () => {
        if (view === 'dressingRoom' || isPreparingDressingRoom) return;

        setIsPreparingDressingRoom(true);

        setTimeout(() => {
            setView('dressingRoom');
            setIsPreparingDressingRoom(false);
        }, 2000); // Show loader for 2 seconds
    };

    const handleUpdateOutfit = (id: string, updates: Partial<Outfit>) => {
        setOutfits(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
    };
    
    const handleDeleteOutfit = (id: string) => {
        setOutfits(prev => prev.filter(o => o.id !== id));
    };

    const handleTryOnOutfit = useCallback(async (outfitToTryOn: Outfit) => {
        if (!avatar?.images || isDressing) return;
        setWornOutfitId(outfitToTryOn.id);
        setIsDressing(true);
        setError(null);
        setDressingRoomImages([outfitToTryOn.images[0]]); 

        try {
            if (!outfitToTryOn.isMock && geminiService.isApiKeySet()) {
                const frontView = await geminiService.dressAvatar(avatar.images[0], outfitToTryOn.images[0]);
                setDressingRoomImages([frontView]);
            } else {
                 setDressingRoomImages(outfitToTryOn.images);
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to dress avatar.');
            if (avatar?.images) setDressingRoomImages(avatar.images);
            setWornOutfitId(null);
        } finally {
            setIsDressing(false);
        }
    }, [avatar, isDressing]);

    const handleCreateAvatar = async () => {
        setIsProcessingAvatar(true);
        setAvatarProgress(0);
        setError(null);
    
        try {
            setAvatarStatusText('Preparing references...');
            let bodyImageB64: string | null = null;
    
            if (poseSource === 'my-outfits' && selectedBodyOutfitId) {
                const outfit = outfits.find(o => o.id === selectedBodyOutfitId);
                bodyImageB64 = outfit ? outfit.images[0] : null;
            } else if (poseSource === 'presets' && selectedPresetPoseId) {
                const pose = PRESET_POSES.find(p => p.id === selectedPresetPoseId);
                if (pose) {
                    bodyImageB64 = await new Promise<string>((resolve, reject) => {
                        const img = new Image();
                        img.crossOrigin = 'Anonymous';
                        img.onload = () => {
                            const canvas = document.createElement('canvas');
                            canvas.width = img.width;
                            canvas.height = img.height;
                            const ctx = canvas.getContext('2d');
                            if (!ctx) {
                                return reject(new Error('Could not get canvas context'));
                            }
                            ctx.drawImage(img, 0, 0);
                            const dataURL = canvas.toDataURL('image/png');
                            resolve(dataURL.split(',')[1]);
                        };
                        img.onerror = () => {
                             reject(new Error(`Failed to load preset pose image. The image may be inaccessible due to cross-origin restrictions.`));
                        };
                        img.src = pose.image;
                    });
                }
            }
    
            if (!faceImage || !bodyImageB64) {
                throw new Error('Please select a headshot and a body pose.');
            }
            
            setAvatarProgress(25);
            
            let newAvatar: Avatar;
    
            if (isDevMode) {
                setAvatarStatusText('Generating avatar (dev mode)...');
                await new Promise(res => setTimeout(res, 1000));
                setAvatarProgress(75);
                await new Promise(res => setTimeout(res, 1000));
                newAvatar = { images: [faceImage], videoUrl: undefined };
            } else {
                setAvatarStatusText('Creating base avatar...');
                const avatarImage = await geminiService.createAvatar(faceImage, bodyImageB64);
                setAvatarProgress(75);
                setAvatarStatusText('Animating avatar...');
                const videoUrl = await geminiService.generateAvatarVideo(avatarImage);
                newAvatar = { images: [avatarImage], videoUrl };
            }
            
            setAvatarProgress(100);
            setAvatarStatusText('Avatar created!');
            setAvatar(newAvatar);
            setDressingRoomImages(newAvatar.images);
    
        } catch (err) {
            console.error("Avatar creation failed:", err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred during avatar creation.');
        } finally {
            setIsProcessingAvatar(false);
        }
    };

    const renderClosetContent = () => {
        return (
            <div data-tutorial-id="tutorial-my-outfits-page">
                {isDevMode && (
                    <div className="flex justify-center items-center gap-4 mb-8">
                    </div>
                )}

                <CategoryFilter activeCategory={activeCategory} setActiveCategory={setActiveCategory} />

                {filteredOutfits.length > 0 ? (
                    <div ref={outfitGridRef} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" style={{ outline: 'none' }} tabIndex={-1}>
                        {filteredOutfits.map((outfit) => (
                            <OutfitCard
                                key={outfit.id}
                                outfit={outfit}
                                onToggleFavorite={() => handleUpdateOutfit(outfit.id, { isFavorite: !outfit.isFavorite })}
                                onUpdate={(updates) => handleUpdateOutfit(outfit.id, updates)}
                                onTryOn={() => { handleSwitchToDressingRoom(); if(avatar) handleTryOnOutfit(outfit); }}
                                onViewDetail={() => setSelectedOutfit(outfit)}
                                onDelete={() => handleDeleteOutfit(outfit.id)}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20">
                        <p className="text-2xl text-gray-400">Your closet is empty.</p>
                        <p className="text-gray-500">Go to the 'Outfit Generator' to add your first style!</p>
                    </div>
                )}
            </div>
        );
    };
    
     const renderDressingRoomContent = () => {
        if (!isDevMode) {
            return <ComingSoonPlaceholder />;
        }

        if (!avatar) {
             return (
                <div className="text-center">
                    <h2 className="text-3xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">Create Your Avatar</h2>
                    <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">Upload a closeup of your face and select an outfit from your closet to generate your virtual self.</p>
                    
                    <div className="grid lg:grid-cols-2 gap-12 items-start">
                        <div className="flex flex-col items-center gap-4">
                            <h3 className="text-2xl font-bold">1. Provide a Closeup of Your Face</h3>
                            <HeadshotUploader onImageSelected={setFaceImage} currentImage={faceImage} disabled={isProcessingAvatar} />
                        </div>
                        <div className="flex flex-col items-center gap-4">
                            <h3 className="text-2xl font-bold">2. Pick Your Outfit</h3>
                            <div className="flex items-center justify-center gap-3 my-4">
                                <span className={`transition-colors duration-300 font-semibold ${poseSource === 'my-outfits' ? 'text-white' : 'text-gray-500'}`}>
                                    My Outfits
                                </span>
                                <label htmlFor="pose-source-toggle" className="relative inline-flex items-center cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        id="pose-source-toggle" 
                                        className="sr-only peer" 
                                        checked={poseSource === 'presets'} 
                                        onChange={() => setPoseSource(prev => prev === 'my-outfits' ? 'presets' : 'my-outfits')} 
                                        disabled={isProcessingAvatar}
                                    />
                                    <div className="w-14 h-8 bg-white/10 rounded-full peer peer-focus:ring-2 peer-focus:ring-[#00f2ff] peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-1 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-gradient-to-r from-[#f400f4] to-[#00f2ff]"></div>
                                </label>
                                <span className={`transition-colors duration-300 font-semibold ${poseSource === 'presets' ? 'text-white' : 'text-gray-500'}`}>
                                    Preset
                                </span>
                            </div>
                            
                            <div className="w-full min-h-[520px]">
                                {poseSource === 'my-outfits' ? (
                                    outfits.length > 0 ? (
                                        <OutfitDeck outfits={outfits} selectedId={selectedBodyOutfitId} onSelect={setSelectedBodyOutfitId} disabled={isProcessingAvatar} size="large" />
                                    ) : (
                                        <div className="text-center py-10 text-gray-400">
                                            You need at least one outfit in your closet to set a body and pose.
                                        </div>
                                    )
                                ) : (
                                    <PoseDeck poses={PRESET_POSES} selectedId={selectedPresetPoseId} onSelect={setSelectedPresetPoseId} disabled={isProcessingAvatar} size="large" />
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="mt-12">
                         {isProcessingAvatar ? (
                            <GenerationLoader progress={avatarProgress} statusText={avatarStatusText} />
                        ) : (
                            <Button 
                                onClick={handleCreateAvatar} 
                                disabled={!faceImage || (poseSource === 'my-outfits' && !selectedBodyOutfitId) || (poseSource === 'presets' && !selectedPresetPoseId)}
                            >
                                Generate My Avatar
                            </Button>
                        )}
                    </div>
                </div>
            );
        }

        return (
            <div className="grid lg:grid-cols-3 gap-8 items-start">
                <div className="lg:col-span-1 flex flex-col items-center gap-4">
                    <div className="relative w-full aspect-[3/4] bg-black/20 rounded-lg overflow-hidden border-2 border-transparent hover:border-[#00f2ff]/50 transition-all duration-300">
                        {isDressing ? <div className="w-full h-full flex items-center justify-center bg-black/50"><Spinner text="Dressing..." /></div>
                        : avatar.videoUrl && wornOutfitId === null ? <AvatarVideoPlayer src={avatar.videoUrl} />
                        : (dressingRoomImages && dressingRoomImages.length > 0 ? (
                                <OutfitViewer
                                    images={dressingRoomImages}
                                    onGenerate360={() => { /* Placeholder */ }}
                                    isGenerating360={isGenerating360}
                                />
                            ) : null
                        )}
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <h3 className="text-3xl font-bold mb-4 text-center">Select an Outfit to Try On</h3>
                    <div className="relative h-[calc(100vh-250px)]">
                        <OutfitDeck outfits={outfits} selectedId={wornOutfitId} onSelect={(id) => handleTryOnOutfit(outfits.find(o => o.id === id)!)} disabled={isDressing} size="large" />
                    </div>
                </div>
            </div>
        );
    };
    
    // When the animation is fading out the `closet` view after the loader,
    // we want to show an empty div instead of the actual closet content to prevent a flicker.
    const isFadingOutClosetAfterLoader = animationClass === 'page-transition-exit' && view === 'dressingRoom' && displayedView === 'closet';

    return (
        <div className="container mx-auto">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-5xl font-extrabold tracking-tight">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
                        {view === 'closet' ? 'My Outfits' : 'Dressing Room'}
                    </span>
                </h1>
                <div
                    className="relative flex w-[22rem] items-center bg-white/10 rounded-full p-1"
                    data-tutorial-id="tutorial-dressing-room-tab"
                >
                    {/* The sliding thumb/background */}
                    <div
                        className="absolute h-full w-1/2 top-0 p-1 transition-transform duration-300 ease-in-out"
                        style={{
                            transform: view === 'dressingRoom' ? 'translateX(100%)' : 'translateX(0%)'
                        }}
                    >
                        <div className="w-full h-full bg-gradient-to-r from-[#f400f4] to-[#00f2ff] rounded-full shadow-[0_0_10px_#f400f4]" />
                    </div>
                    
                    {/* Button for Closet */}
                    <button
                        onClick={() => setView('closet')}
                        className={`relative z-10 flex-1 py-2 text-lg font-semibold text-center transition-colors duration-300 ${
                            view === 'closet' ? 'text-white' : 'text-gray-300'
                        }`}
                    >
                        Closet
                    </button>

                    {/* Button for Dressing Room */}
                    <button
                        onClick={handleSwitchToDressingRoom}
                        className={`relative z-10 flex-1 py-2 text-lg font-semibold text-center transition-colors duration-300 ${
                            view === 'dressingRoom' ? 'text-white' : 'text-gray-300'
                        }`}
                    >
                        Dressing Room
                    </button>
                </div>
            </div>
             {error && <div className="my-4 p-3 bg-red-500/20 border border-red-500 text-red-300 rounded-md text-sm text-center"><p>{error}</p></div>}
            {isPreparingDressingRoom ? (
                <DressingRoomLoader />
            ) : (
                <div className={animationClass}>
                    {isFadingOutClosetAfterLoader ? (
                        <div /> // Render an empty div to prevent the closet from flickering back into view
                    ) : (
                        displayedView === 'closet' ? renderClosetContent() : renderDressingRoomContent()
                    )}
                </div>
            )}
        </div>
    );
};

export default MyOutfitsPage;