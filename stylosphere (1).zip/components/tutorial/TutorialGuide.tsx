import React, { useState, useEffect, useRef } from 'react';
import { useTutorial } from '../../contexts/TutorialContext';
import Button from '../shared/Button';

export const TutorialGuide: React.FC = () => {
    const { isTutorialActive, currentStep, nextStep, stopTutorial } = useTutorial();
    const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
    const [isVisible, setIsVisible] = useState(false);
    const tooltipRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        // FIX: Use `number[]` for setTimeout return type in browser environments instead of `NodeJS.Timeout[]`.
        const allTimers: number[] = [];

        if (isTutorialActive && currentStep) {
            const findElement = () => {
                const element = document.querySelector(`[data-tutorial-id="${currentStep.elementId}"]`);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    // Wait for scrolling to finish before calculating position and showing
                    // FIX: Use window.setTimeout to avoid NodeJS.Timeout type conflict.
                    allTimers.push(window.setTimeout(() => {
                        setTargetRect(element.getBoundingClientRect());
                        setIsVisible(true);
                    }, 300));
                } else {
                    // Retry if the element isn't there yet (e.g., page is transitioning)
                    // FIX: Use window.setTimeout to avoid NodeJS.Timeout type conflict.
                    allTimers.push(window.setTimeout(findElement, 100));
                }
            };
            // Initial delay to allow page transitions to complete
            // FIX: Use window.setTimeout to avoid NodeJS.Timeout type conflict.
            allTimers.push(window.setTimeout(findElement, 400));
        } else {
            setIsVisible(false); // Trigger fade-out
            // After fade-out animation, unmount the component
            // FIX: Use window.setTimeout to avoid NodeJS.Timeout type conflict.
            allTimers.push(window.setTimeout(() => setTargetRect(null), 500));
        }

        return () => allTimers.forEach(window.clearTimeout);
    }, [currentStep, isTutorialActive]);

    const getTooltipPosition = () => {
        if (!targetRect || !tooltipRef.current) return {};
        
        const tooltipHeight = tooltipRef.current.offsetHeight;
        const tooltipWidth = tooltipRef.current.offsetWidth;
        const spacing = 15;
        const vw = window.innerWidth;
        const vh = window.innerHeight;

        let pos = { top: 0, left: 0 };
        const position = currentStep?.position || 'bottom';

        switch (position) {
            case 'top':
                pos = { top: targetRect.top - tooltipHeight - spacing, left: targetRect.left + targetRect.width / 2 - tooltipWidth / 2 };
                break;
            case 'right':
                pos = { top: targetRect.top + targetRect.height / 2 - tooltipHeight / 2, left: targetRect.right + spacing };
                break;
            case 'left':
                pos = { top: targetRect.top + targetRect.height / 2 - tooltipHeight / 2, left: targetRect.left - tooltipWidth - spacing };
                break;
            case 'bottom':
            default:
                pos = { top: targetRect.bottom + spacing, left: targetRect.left + targetRect.width / 2 - tooltipWidth / 2 };
                break;
        }

        // Keep tooltip on screen
        pos.left = Math.max(spacing, Math.min(pos.left, vw - tooltipWidth - spacing));
        pos.top = Math.max(spacing, Math.min(pos.top, vh - tooltipHeight - spacing));

        return pos;
    };
    
    if (!targetRect) {
        return null;
    }

    return (
        <div className="fixed inset-0 z-[100] pointer-events-none">
            {/* Spotlight Effect */}
            <div
                className="absolute border-[5px] border-[#00f2ff] rounded-lg tutorial-highlight"
                style={{
                    top: targetRect.top - 8,
                    left: targetRect.left - 8,
                    width: targetRect.width + 16,
                    height: targetRect.height + 16,
                    opacity: isVisible ? 1 : 0,
                    transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                }}
            />

            {/* Tooltip */}
            <div
                ref={tooltipRef}
                className="absolute bg-[#1a0a37]/90 backdrop-blur-md border border-[#00f2ff]/50 rounded-lg p-4 w-80 shadow-2xl shadow-[#00f2ff]/30 pointer-events-auto"
                style={{
                    ...getTooltipPosition(),
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0) scale(1)' : 'translateY(15px) scale(0.95)',
                    transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                }}
            >
                <h3 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff] mb-2">{currentStep?.title}</h3>
                <p className="text-gray-300 text-sm mb-4">{currentStep?.content}</p>
                <div className="flex justify-between items-center">
                    <Button onClick={stopTutorial} variant="secondary" className="px-3 py-1 text-xs">Skip Tour</Button>
                    <Button onClick={nextStep} className="px-4 py-1 text-sm">Next</Button>
                </div>
            </div>
        </div>
    );
};