import React, { useState } from 'react';
import Button from '../shared/Button';

interface OnboardingModalProps {
    onSave: (name: string) => void;
}

const OnboardingModal: React.FC<OnboardingModalProps> = ({ onSave }) => {
    const [name, setName] = useState('');

    const handleSave = () => {
        if (name.trim()) {
            onSave(name.trim());
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-[#0a0118] to-[#1a0a37]">
            <div className="w-full max-w-md p-8 space-y-6 bg-black/20 backdrop-blur-lg border border-white/10 rounded-lg shadow-2xl shadow-[#00f2ff]/20 page-transition-enter">
                <div className="text-center">
                    <h1 className="text-4xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
                        Welcome to StyloSphere!
                    </h1>
                    <p className="mt-2 text-xl text-gray-300">What should we call you?</p>
                </div>
                <div className="space-y-4">
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSave()}
                        placeholder="Enter your name"
                        required
                        className="w-full bg-white/5 border border-white/20 rounded-md px-4 py-3 text-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#00f2ff] transition-all text-center"
                    />
                    <Button onClick={handleSave} disabled={!name.trim()} className="w-full py-3 text-lg">
                        Continue
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default OnboardingModal;
