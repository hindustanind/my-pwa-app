import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../shared/Button';

interface LoginPageProps {
    onSwitchToSignUp: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onSwitchToSignUp }) => {
    const [emailOrUsername, setEmailOrUsername] = useState('');
    const [password, setPassword] = useState('');
    const [keepLoggedIn, setKeepLoggedIn] = useState(true);
    const [error, setError] = useState('');
    const { login } = useAuth();

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!login(emailOrUsername, password, keepLoggedIn)) {
            setError('Invalid credentials. Please try again.');
        }
        // On successful login, the AuthContext will update and App.tsx will re-render the main app.
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0118] to-[#1a0a37]">
            <div className="w-full max-w-md p-8 space-y-8 bg-black/20 backdrop-blur-lg border border-white/10 rounded-lg shadow-2xl shadow-[#00f2ff]/20 page-transition-enter">
                <div className="text-center">
                    <h1 className="text-4xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
                        Welcome Back
                    </h1>
                    <p className="mt-2 text-gray-400">Log in to access your virtual closet.</p>
                </div>
                <form className="space-y-6" onSubmit={handleLogin}>
                    {error && <p className="text-center text-red-400 bg-red-500/10 p-2 rounded-md">{error}</p>}
                    <div>
                        <input
                            type="text"
                            value={emailOrUsername}
                            onChange={(e) => setEmailOrUsername(e.target.value)}
                            placeholder="Email or Username"
                            required
                            className="w-full bg-white/5 border border-white/20 rounded-md px-4 py-3 text-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#00f2ff] transition-all"
                        />
                    </div>
                    <div>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Password"
                            required
                            className="w-full bg-white/5 border border-white/20 rounded-md px-4 py-3 text-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#00f2ff] transition-all"
                        />
                    </div>
                     <div className="flex items-center justify-between">
                        <div className="flex items-center">
                            <input
                                id="keep-logged-in"
                                name="keep-logged-in"
                                type="checkbox"
                                checked={keepLoggedIn}
                                onChange={(e) => setKeepLoggedIn(e.target.checked)}
                                className="h-4 w-4 rounded border-gray-400 bg-white/10 text-[#f400f4] focus:ring-[#00f2ff] cursor-pointer"
                            />
                            <label htmlFor="keep-logged-in" className="ml-2 block text-sm text-gray-300 cursor-pointer">
                                Keep me signed in
                            </label>
                        </div>
                    </div>
                    <div>
                        <Button type="submit" className="w-full py-3 text-lg">Log In</Button>
                    </div>
                </form>
                <p className="text-center text-gray-400">
                    Don't have an account?{' '}
                    <button onClick={onSwitchToSignUp} className="font-medium text-[#00f2ff] hover:underline">
                        Sign Up
                    </button>
                </p>
            </div>
        </div>
    );
};

export default LoginPage;