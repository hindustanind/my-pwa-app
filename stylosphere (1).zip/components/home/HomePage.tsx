
import React, { useState, useEffect, useMemo } from 'react';
import Button from '../shared/Button';

// --- Image URLs categorized by gender ---
const FEMALE_IMAGES = [
  'https://drive.google.com/thumbnail?id=17E6CavrK2j9h7DPlTG_wB9PFOkpLEEqD&sz=w1000',
  'https://drive.google.com/thumbnail?id=1761byymEKax47rwttnP3UGbIkC1erb1c&sz=w1000',
  'https://drive.google.com/thumbnail?id=16jyN4f6xgE4tolLSysaN7KUFxXJfNNpp&sz=w1000',
  'https://drive.google.com/thumbnail?id=16V9YWGCtRhxEtpbJXXMa5S9AmqHfjtbM&sz=w1000',
  'https://drive.google.com/thumbnail?id=17JZAs4CxgFAi6wRXjOLAo_kVnz4ge5uH&sz=w1000',
  'https://drive.google.com/thumbnail?id=16fMdIQGbKYK6rdx_jg3khtfr3pFgTErE&sz=w1000',
  'https://drive.google.com/thumbnail?id=16cFfL8Ou8_LRzWG9Z3COSrGNsDi-Sh8y&sz=w1000',
  'https://drive.google.com/thumbnail?id=16IOdQnPHDA2rj1dRUxAq9KnaLljffjdC&sz=w1000',
];

const MALE_IMAGES = [
  'https://drive.google.com/thumbnail?id=17PTX68HZJYJRa6_EKqnsHhTzgU-4bEPs&sz=w1000',
  'https://drive.google.com/thumbnail?id=17QjXOoKDCOU4RN0G_GIIrqMm0YHKummd&sz=w1000',
  'https://drive.google.com/thumbnail?id=17CzwmI4cPC2bonStEgkKLNAhmVI_9FIw&sz=w1000',
  'https://drive.google.com/thumbnail?id=17DQ_LHrGlL-ybPphOjSRAQEkmlR_pSmc&sz=w1000',
  'https://drive.google.com/thumbnail?id=16kETuaDF2JvPaCBHWuj0LtY_eXO8fW-I&sz=w1000',
  'https://drive.google.com/thumbnail?id=16izYHnvhRbe08EXqJI685aD4C31aWZR9&sz=w1000',
  'https://drive.google.com/thumbnail?id=16YbeW0DpngoT3ag_DZqVwxs3r6ro4Loq&sz=w1000',
];

// Helper function to shuffle an array (Fisher-Yates)
const shuffleArray = <T,>(array: T[]): T[] => {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
};


interface HomePageProps {
  onGetStarted: () => void;
  userName: string;
}

const HomePage: React.FC<HomePageProps> = ({ onGetStarted, userName }) => {
    // Randomize and interleave images on component mount to create a dynamic, alternating sequence.
    const HOMEPAGE_IMAGES = useMemo(() => {
        const shuffledFemale = shuffleArray(FEMALE_IMAGES);
        const shuffledMale = shuffleArray(MALE_IMAGES);

        const interleaved = [];
        const maxLength = Math.max(shuffledFemale.length, shuffledMale.length);
        
        // To add variety, randomly decide if the sequence starts with a male or female image
        const startsWithFemale = Math.random() < 0.5;
        const arr1 = startsWithFemale ? shuffledFemale : shuffledMale;
        const arr2 = startsWithFemale ? shuffledMale : shuffledFemale;

        for (let i = 0; i < maxLength; i++) {
            if (i < arr1.length) {
                interleaved.push(arr1[i]);
            }
            if (i < arr2.length) {
                interleaved.push(arr2[i]);
            }
        }
        return interleaved;
    }, []);

    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        if (HOMEPAGE_IMAGES.length < 2) return;
        const interval = setInterval(() => {
            setCurrentIndex(prevIndex => (prevIndex + 1) % HOMEPAGE_IMAGES.length);
        }, 2000); // Fast-paced transition every 2 seconds

        return () => clearInterval(interval);
    }, [HOMEPAGE_IMAGES.length]);


    // Carousel configuration
    const carouselConfig = {
        rotateY: -20,
        translateZ: -180,
        translateX: 35,
    };

    return (
        <div className="w-full h-full">
            {/* Full-screen hero section */}
            <div 
                className="relative w-full h-full flex flex-col items-center justify-center gap-8 overflow-hidden"
                style={{ perspective: '1200px' }}
            >
                {/* Greeting & CTA */}
                <div className="z-10 text-center animate-fade-in space-y-4">
                    <h1 
                        className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]"
                        style={{ fontSize: 'clamp(32px, 5vw, 52px)' }}
                    >
                        Welcome, {userName}!
                    </h1>
                    <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                        Your AI-powered virtual closet and stylist. Upload outfits, create an avatar, and get personalized fashion advice.
                    </p>
                    <div className="pt-4">
                        <Button onClick={onGetStarted} className="px-8 py-3 text-lg">
                            Get Started
                        </Button>
                    </div>
                </div>

                {/* Carousel */}
                <div 
                    className="relative w-[60%] sm:w-[40%] md:w-[30%] lg:w-[25%] aspect-[3/4]"
                    style={{ transformStyle: 'preserve-3d' }}
                >
                    {HOMEPAGE_IMAGES.map((src, index) => {
                        const len = HOMEPAGE_IMAGES.length;
                        const diff = index - currentIndex;
                        let offset;

                        if (len <= 1) {
                            offset = 0;
                        } else if (Math.abs(diff) <= len / 2) {
                            offset = diff;
                        } else if (diff > 0) {
                            offset = diff - len;
                        } else {
                            offset = diff + len;
                        }
                        
                        const rotateY = offset * carouselConfig.rotateY;
                        const translateZ = Math.abs(offset) * carouselConfig.translateZ;
                        const translateX = offset * carouselConfig.translateX;
                        const scale = offset === 0 ? 1 : 0.9;

                        return (
                            <div
                                key={index}
                                className="absolute top-0 left-0 w-full h-full transition-all duration-500 rounded-lg overflow-hidden"
                                style={{
                                    transform: `translateX(${translateX}%) rotateY(${rotateY}deg) translateZ(${translateZ}px) scale(${scale})`,
                                    zIndex: HOMEPAGE_IMAGES.length - Math.abs(offset),
                                    opacity: Math.abs(offset) > 2 ? 0 : 1, // Fade out cards that are far away
                                    transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
                                }}
                            >
                                <img
                                    src={src}
                                    alt={`Fashion showcase ${index + 1}`}
                                    className="w-full h-full object-cover"
                                    draggable="false"
                                    onError={(e) => {
                                        e.currentTarget.style.display = 'none'; // Hide broken images
                                    }}
                                />
                                <div 
                                    className="absolute inset-0 bg-black/50 transition-opacity duration-500"
                                    style={{
                                        opacity: offset === 0 ? 0 : 0.6 // Darken non-active cards
                                    }}
                                />
                            </div>
                        );
                    })}
                </div>
                
                {/* Vignette Effect */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0118] via-[#0a0118]/50 to-transparent pointer-events-none"></div>
            </div>
        </div>
    );
};

export default HomePage;
