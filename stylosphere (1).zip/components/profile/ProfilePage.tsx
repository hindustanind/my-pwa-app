import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import ProfileHeader from './ProfileHeader';
import { useAuth } from '../../contexts/AuthContext';

type Page = 'home' | 'generator' | 'closet' | 'ava' | 'profile';

interface ProfilePageProps {
  viewedUserId: string | null;
  onNavigate: (page: Page, userId?: string | null) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ viewedUserId, onNavigate }) => {
  const { currentUser, getUser, updateUser } = useAuth();
  const [viewedUser, setViewedUser] = useState<User | null>(null);

  useEffect(() => {
    const userToView = getUser(viewedUserId || currentUser!.id);
    setViewedUser(userToView || null);
  }, [viewedUserId, getUser, currentUser]);

  const isOwnProfile = !viewedUserId || viewedUserId === currentUser?.id;
  
  if (!viewedUser) {
      return <div className="text-center py-20 text-gray-400">User not found.</div>;
  }

  return (
    <div className="container mx-auto max-w-7xl page-transition-enter space-y-8">
      <div data-tutorial-id="tutorial-profile-page">
        <ProfileHeader
          user={viewedUser}
          onUpdateUser={updateUser}
          isOwnProfile={isOwnProfile}
        />
      </div>
       <div className="text-center py-10">
        <p className="text-gray-500">Your showcase and closet have been simplified in this version.</p>
      </div>
    </div>
  );
};

export default ProfilePage;
