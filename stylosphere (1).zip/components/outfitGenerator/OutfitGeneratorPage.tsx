
import React, { useState } from 'react';
import { Outfit, OutfitCategory } from '../../types';
import * as geminiService from '../../services/geminiService';
import { OUTFIT_CATEGORIES } from '../../constants';
import ImageUploader from './ImageUploader';
import OutfitViewer from './OutfitViewer';
import Button from '../shared/Button';
import GenerationLoader from './GenerationLoader';
import useLocalStorage from '../../hooks/useLocalStorage';
import { fileToBase64, compressImage } from '../../utils';

interface OutfitGeneratorPageProps {
  onOutfitSaved: (outfit: Omit<Outfit, 'id' | 'createdAt'>) => void;
  isDevMode: boolean;
  userName: string | null;
}

type GenerationStatus = 'idle' | 'loading' | 'done' | 'error';
    
interface GeneratedOutfitData {
  images: string[];
  category: OutfitCategory;
  description: string;
  isMock?: boolean;
}

const OutfitGeneratorPage: React.FC<OutfitGeneratorPageProps> = ({ onOutfitSaved, isDevMode, userName }) => {
    const [status, setStatus] = useState<GenerationStatus>('idle');
    const [progress, setProgress] = useState(0);
    const [statusText, setStatusText] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [generatedOutfit, setGeneratedOutfit] = useState<GeneratedOutfitData | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [hasGeneratedOutfit, setHasGeneratedOutfit] = useLocalStorage<boolean>('stylosphere-has-generated-outfit', false);


    const handleImageUpload = async (file: File) => {
        setStatus('loading');
        setProgress(0);
        setStatusText('Initializing...');
        setError(null);
        setGeneratedOutfit(null);

        try {
            if (isDevMode) {
                // MOCK GENERATION
                const imageBase64 = await fileToBase64(file);
                setProgress(20); setStatusText('Cleaning up the image...'); await new Promise(res => setTimeout(res, 500));
                setProgress(60); setStatusText('Generating 360° views...'); await new Promise(res => setTimeout(res, 500));
                setProgress(80); setStatusText('Analyzing outfit style...'); await new Promise(res => setTimeout(res, 500));
                setProgress(100); setStatusText('Crafting your style profile...'); await new Promise(res => setTimeout(res, 500));

                const mockImages = Array(8).fill(imageBase64);
                const possibleCategories = OUTFIT_CATEGORIES.filter(c => c !== OutfitCategory.ALL && c !== OutfitCategory.UNKNOWN);
                const mockCategory = possibleCategories[Math.floor(Math.random() * possibleCategories.length)];
                const mockDescription = `Looking fantastic, ${userName || 'you'}! This outfit has a really cool vibe. The colors are great and it looks super comfortable yet stylish. This would be perfect for a weekend brunch or a casual day out with friends. You've got great taste!`;
                
                setGeneratedOutfit({ images: mockImages, category: mockCategory, description: mockDescription, isMock: true });
                setStatus('done');
            } else {
                // REAL GENERATION
                if (!geminiService.isApiKeySet()) {
                  throw new Error("The application is not configured with an API key.");
                }
                setProgress(20); setStatusText('Cleaning up the image...');
                const frontView = await geminiService.generateCleanFrontView(file);

                setProgress(60); setStatusText('Generating 360° views...');
                const allViews = await geminiService.generate360Views(frontView);

                setProgress(80); setStatusText('Analyzing outfit style...');
                const category = await geminiService.categorizeOutfit(frontView);

                setProgress(95); setStatusText('Crafting your style profile...');
                const description = await geminiService.generateOutfitCompliment(frontView, userName || 'friend');
                
                setGeneratedOutfit({ images: allViews, category, description, isMock: false });
                setStatus('done');
                setProgress(100);
            }
        } catch (err) {
            console.error("Outfit generation failed:", err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
            setStatus('error');
        }
    };
    
    const handleSave = async () => {
        if (!generatedOutfit) return;
        setIsSaving(true);
        if (!hasGeneratedOutfit) {
            setHasGeneratedOutfit(true);
        }
        try {
            const compressedImages = await Promise.all(
                generatedOutfit.images.map(image => compressImage(image))
            );
            const outfitToSave: Omit<Outfit, 'id' | 'createdAt'> = {
                images: compressedImages,
                category: generatedOutfit.category,
                isMock: generatedOutfit.isMock,
                name: `${generatedOutfit.category} Style #${Math.floor(100 + Math.random() * 900)}`,
                tags: [generatedOutfit.category],
            };
            onOutfitSaved(outfitToSave);
            // The parent component will handle navigation, unmounting this page.
            // When it mounts again, state will be reset.
        } catch (err) {
            console.error("Failed to compress and save outfit:", err);
            setError("Failed to save the outfit. Please try again.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleReset = () => {
        setStatus('idle');
        setGeneratedOutfit(null);
        setError(null);
        setProgress(0);
        setStatusText('');
    };

    const handleDownloadImage = (imageUrl: string, angle: string) => {
        const link = document.createElement('a');
        link.href = `data:image/png;base64,${imageUrl}`;
        link.download = `StyloSphere-Outfit-${angle.replace(/\s+/g, '-')}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const renderContent = () => {
        if (status === 'loading') {
            return (
                <div key="loading" className="page-transition-enter flex items-center justify-center min-h-[60vh]">
                    <GenerationLoader progress={progress} statusText={statusText} />
                </div>
            );
        }
        
        if (status === 'error') {
            return (
                <div key="error" className="page-transition-enter flex flex-col items-center justify-center min-h-[60vh]">
                    <div className="my-8 p-4 bg-red-500/20 border border-red-500 text-red-300 rounded-md text-center max-w-lg">
                        <p className="font-bold">Operation Failed</p>
                        <p>{error}</p>
                        <Button onClick={handleReset} variant="secondary" className="mt-4">Try Again</Button>
                    </div>
                </div>
            );
        }

        if (status === 'done' && generatedOutfit) {
            const { images, category, description } = generatedOutfit;
            return (
                 <div key="done" className="page-transition-enter flex flex-col items-center gap-8 w-full py-8">
                    <div className="w-full max-w-md">
                        <OutfitViewer 
                            images={images} 
                            showDownloadButton={true} 
                            onDownload={handleDownloadImage}
                            showInitialDragHint={!hasGeneratedOutfit || isDevMode}
                        />
                    </div>
                    <div className="text-center space-y-6 w-full max-w-md">
                        <div>
                            <p className="text-sm font-bold text-[#00f2ff] uppercase tracking-wider">Style Category</p>
                            <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">{category}</h2>
                        </div>
                        <div className="bg-white/5 p-4 rounded-md border border-white/10">
                            <p className="text-lg text-gray-300">{description || 'Analyzing your style...'}</p>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Button onClick={handleSave} disabled={isSaving} className="w-full sm:w-auto">
                                {isSaving ? 'Saving...' : 'Move to My Outfits'}
                            </Button>
                            <Button onClick={handleReset} variant="secondary" disabled={isSaving} className="w-full sm:w-auto">Generate Another</Button>
                        </div>
                    </div>
                </div>
            );
        }

        // Default to idle state
        return (
            <div key="idle" className="page-transition-enter grid md:grid-cols-2 gap-12 items-center" data-tutorial-id="tutorial-generator-uploader">
                <ImageUploader onImageUpload={handleImageUpload} />
                <div className="text-left space-y-4">
                    <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f400f4] to-[#00f2ff]">
                            Bring Your Style to Life.
                        </span>
                    </h1>
                    <p className="text-xl text-gray-300">
                        Have an outfit you love? Drop a photo here. Our AI, AVA, will work her magic to create a stunning 360° digital version for your virtual closet.
                    </p>
                    <ul className="list-disc list-inside space-y-2 text-gray-400">
                        <li>AVA cleans up the background for a professional look.</li>
                        <li>Generates a full 360-degree interactive view.</li>
                        <li>Automatically categorizes the style for you.</li>
                    </ul>
                    <p className="text-lg text-[#00f2ff] font-semibold">
                        Ready to digitize your wardrobe? Let's begin!
                    </p>
                </div>
            </div>
        );
    };

    return (
        <div className="container mx-auto max-w-7xl">
            {isDevMode && status === 'idle' && (
                <div className="mb-4 p-3 bg-[#00f2ff]/10 border border-[#00f2ff]/30 rounded-md text-[#00f2ff] text-center">
                    <strong>Developer Mode is ON.</strong> AI generation will be skipped, but you'll see the loading animation.
                </div>
            )}
            {renderContent()}
        </div>
    );
};

export default OutfitGeneratorPage;
