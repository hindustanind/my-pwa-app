
import React, { useState, useEffect } from 'react';
import MusicPlayer from '../shared/MusicPlayer';
import { MUSIC_TRACKS } from '../../constants';

interface GenerationLoaderProps {
  progress: number;
  statusText: string;
}

const ENGAGING_TEXTS = [
    "Analyzing fabric textures and patterns...",
    "Did you know? The little pocket in your jeans was originally for pocket watches.",
    "Considering color theory and complementary shades...",
    "Fashion is architecture: it is a matter of proportions. - Coco Chanel",
    "Scanning our style database for similar aesthetics...",
    "The first fashion magazine was sold in Germany in 1586.",
    "Polishing pixels for a photorealistic finish...",
    "AVA is learning your unique style preferences.",
    "Fun fact: The T-shirt was first introduced in 1904 for bachelors who couldn't sew buttons.",
    "Building a 3D model from your 2D image...",
];

const GenerationLoader: React.FC<GenerationLoaderProps> = ({ progress, statusText }) => {
    const [engagingText, setEngagingText] = useState(ENGAGING_TEXTS[0]);

    useEffect(() => {
        const interval = setInterval(() => {
            setEngagingText(prevText => {
                const currentIndex = ENGAGING_TEXTS.indexOf(prevText);
                const nextIndex = (currentIndex + 1) % ENGAGING_TEXTS.length;
                return ENGAGING_TEXTS[nextIndex];
            });
        }, 3000); // Change text every 3 seconds

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto space-y-8 animate-fade-in">
            <div className="w-full text-center">
                <p className="text-xl font-semibold text-[#00f2ff] mb-3">{statusText}</p>
                 <div className="w-full bg-white/10 rounded-full h-4 overflow-hidden border border-white/20 shadow-inner">
                    <div
                        className="bg-gradient-to-r from-[#f400f4] to-[#00f2ff] h-full rounded-full transition-all duration-500 ease-out"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
            </div>
            <div className="text-center text-gray-400 h-10">
                <p key={engagingText} className="animate-fade-in">{engagingText}</p>
            </div>
            <div className="mt-4 w-full max-w-xs">
                <div className={`transition-opacity duration-500 ease-in-out ${progress >= 60 && progress < 100 ? 'opacity-100' : 'opacity-0'}`}>
                    <p className="text-center text-sm text-gray-400 mb-2">Chill out while you wait</p>
                    <MusicPlayer tracks={MUSIC_TRACKS} />
                </div>
            </div>
        </div>
    );
};

export default GenerationLoader;
