import React from 'react';

const GlobalTaskProcessor: React.FC = () => {
  // This is a placeholder for a removed feature. It renders nothing.
  return null;
};

export default GlobalTaskProcessor;
