import React from 'react';

const NotificationsDropdown: React.FC = () => {
  // This is a placeholder for a removed feature. It renders nothing.
  return null;
};

export default NotificationsDropdown;
