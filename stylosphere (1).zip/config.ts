// This file has been emptied as part of a feature removal.
// Adding a placeholder export to ensure it's treated as a valid module.
export const config = {};
