import React, { createContext, useContext, ReactNode, useMemo, useCallback } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { User } from '../types';

interface AuthContextType {
    currentUser: User | null;
    initializeUser: (username: string) => void;
    updateUser: (userId: string, updates: Partial<User>) => void;
    getUser: (userId: string) => User | undefined;
    logout: () => void; // Keeping logout name, maps to reset
    // Stubs for components that might still destructure them
    users: User[];
    login: (emailOrUsername: string, password: string, keepLoggedIn: boolean) => boolean;
    signup: (username: string, email: string, password: string) => boolean;
}


export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [currentUser, setCurrentUser] = useLocalStorage<User | null>('stylosphere-currentUser', null);

    const initializeUser = useCallback((username: string) => {
        const newUser: User = {
            id: `user-${Date.now()}`,
            username: username.trim(),
            // Use a dummy email, as it's not needed for login but is part of the User type
            email: `${username.trim().toLowerCase().replace(/\s+/g, '')}@stylosphere.local`,
            profilePicture: null,
            styleSignature: `Exploring the world of fashion with StyloSphere!`,
        };
        setCurrentUser(newUser);
    }, [setCurrentUser]);

    const logout = useCallback(() => {
        // This function now resets the app to the onboarding state.
        setCurrentUser(null);
    }, [setCurrentUser]);

    const updateUser = useCallback((userId: string, updates: Partial<User>) => {
        // Only update if the user is the current user.
        if (currentUser && currentUser.id === userId) {
            setCurrentUser(prevUser => {
                if (!prevUser) return null;
                return { ...prevUser, ...updates };
            });
        }
    }, [currentUser, setCurrentUser]);

    const getUser = useCallback((userId: string): User | undefined => {
        if (currentUser && currentUser.id === userId) {
            return currentUser;
        }
        return undefined;
    }, [currentUser]);

    const value = useMemo(() => ({
        currentUser,
        initializeUser,
        updateUser,
        getUser,
        logout,
        // Provide stubs for other functions to prevent crashes
        users: currentUser ? [currentUser] : [],
        login: () => { console.warn("Login function is disabled."); return false; },
        signup: () => { console.warn("Signup function is disabled."); return false; },
    }), [currentUser, initializeUser, updateUser, getUser, logout]);


    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
